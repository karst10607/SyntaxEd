str1 = "this is a test that is a test"

str1.split("test that")[1]

list2 = str1.split("a")

print(list2)

print(list2[1])

str1.split("a")[1]