# this is the simplest python program

#print ("Hello Yoyo from Cloud9!")

# click the 'Run' button at the top to start this application

#!/usr/bin/python
# -*- coding: UTF-8 -*-
import re
import os, sys
from nltk.stem.wordnet import WordNetLemmatizer
from collections import Counter
import csv

list=['(A)','(B)','(C)','(D)']
dict={}
lmtzr = WordNetLemmatizer()
result=""
count=0

if(os.path.exists("result.txt")):os.remove("result.txt")
for root, dirs, files in os.walk("corpus"):
    #print("Root = ", root, "dirs = ", dirs, "files = ", files)
    for f in files:
        print ("File : ", f)
        with open(root+'/'+f, 'r') as fl:
            for line in fl:
                temp=re.sub("[^a-zA-Z +\(\)]"," ",line)
                #print ("Source:"+line.replace("\n",""))
                for ls in list:
                    temp=temp.replace(ls,"")
                temp=re.sub(" +"," ",temp).strip()
                temp=re.sub("[^a-zA-Z ]","",temp)
                #print ("Change:"+temp)
                list2=temp.split(' ')
                for l in list2:
                    if(l!=''):
                        ss=lmtzr.lemmatize(l.lower(),'v')
                        ss=lmtzr.lemmatize(ss)
                        result+=ss+" "
            with open("result.txt","a") as wr:
                wr.write(result)
#os.system("pause")

with open("result.txt","r") as cn:
    temp=cn.read()
    cnt=Counter(temp.split(' '))  
    """
    with open("printOut.txt","w") as w:
        for pairs in cnt.most_common(1000):
            print (pairs[0]+'('+str(pairs[1])+')')
            w.write(pairs[0]+'('+str(pairs[1])+')'+'\t')
    """
    headers=['WORDS','CHINESE',"FREQUENCY"]
    with open("test.csv","w") as ww:
        csv_w=csv.writer(ww)
        csv_w.writerow(headers)
        for pairs in cnt.most_common(2600):
            row=[pairs[0],'',str(pairs[1])]
            csv_w.writerow(row)
    print ("Parsing finished.")
    #print cnt.most_common(20)
    #print cnt.most_common(20)[10:] #['the']
    
