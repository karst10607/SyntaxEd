# for Amy the junior high school student
 #NOT YET modified or create junior corpus


import re
import os
from nltk.stem.wordnet import WordNetLemmatizer
from collections import Counter

list=['(A)','(B)','(C)','(D)']
dict={}
lmtzr = WordNetLemmatizer()
result=""
count=0

if(os.path.exists("result_2.txt")):os.remove("result_2.txt")
for root, dirs, files in os.walk("corpus_junior"):
    #print("Root = ", root, "dirs = ", dirs, "files = ", files)
    for f in files:
        print ("File : ", f)
        with open(root+'/'+f, 'r') as fl:
            for line in fl:
                temp=re.sub("[^a-zA-Z +\(\)]","",line)
                #print ("Source:"+line.replace("\n",""))
                for ls in list:
                    temp=temp.replace(ls,"")
                temp=re.sub(" +"," ",temp).strip()
                #print ("Change:"+temp)
                list2=temp.split(' ')
                for l in list2:
                    if(l!=''):
                        ss=lmtzr.lemmatize(l.lower(),'v')
                        ss=lmtzr.lemmatize(ss)
                        result+=ss+" "
            with open("result_2.txt","a") as wr:
                wr.write(result)
#os.system("pause")
with open("result_2.txt","r") as cn:
    temp=cn.read()
    cnt=Counter(temp.split(' '))  
    
    with open("printOut_2.txt","w") as w:
        for pairs in cnt.most_common(1000):
            print (pairs[0]+'('+str(pairs[1])+')')
            w.write(pairs[0]+'('+str(pairs[1])+')'+'\t')
            
    #print cnt.most_common(20)
    #print cnt.most_common(20)[10:] #['the']
    


